let map;

async function initMap() {
  const { Map } = await google.maps.importLibrary("maps");

  map = new Map(document.getElementById("map"), {
    center: { lat: 18.26293, lng: 83.39318 },
    zoom: 8,
  });
}

initMap();