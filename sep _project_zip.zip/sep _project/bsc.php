<html>
    <head>
        <title>
            btech 
        </title>
        <link rel="stylesheet" href="bsc.css" type="text/css">
    </head>
    <body>

        
        <div class="navbar">
            <div class="logo">
                <h1>BSC DEPARTMENT</h1>

            </div>
            <div class="menu">
                <ul>
                <li><a href="home.php">Home</a></li>
                
                <li><a href="#">Labs</a></li>
                <li><a href="#">Services</a></li>
            
            

                </ul>

            </div>
            

        </div>
        <div class="body">
            <div class="heading">
             <h1>BSC</h1>
             <br>
             <p>BSC Full Form is Bachelor of Science. It is a bachelor's degree given for courses that typically take three years to complete.    </p>
             <br>
             <br> 
             <a href="#">Learn More</a>  
            </div>
            <div class="Sub Branch">
                <div class="Anesthesia">
                    
                    <img src="ANESTHESIA.png" style="width: 200px; height: 150px; border-radius: 12px;">
                    <br>
                    <br>
                    <a href="anesgallery.html">Anesthesia</a>

                </div>
                <div class="Optometry">
                    
                    <img src="OPTOMETRY.png" style="width: 200px; height: 150px; border-radius: 12px;">
                    <br>
                    <br>
                    <a href="optgallery.html">Optometry</a>

                </div>
                
                
                <div class="Radiology">
                    
                    <img src="RADIOLOGY.png" style="width: 200px; height: 150px; border-radius: 12px;">
                    <br>
                    <br>
                    <a href="radgallery.html">Radiology</a>

                </div>
               
            </div>
        </div>
        <div class="footer">
            <a href="#">copy right</a>
            <a href="#">terms and conditions</a>
            <a href="#">privacy policy</a>
            <a href="#">cookies</a>
            <a href="#">complaints</a>
        </div>
    </body>
</html>