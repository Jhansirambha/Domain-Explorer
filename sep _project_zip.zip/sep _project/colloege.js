function submitForm() {
    // You can perform any additional logic here before navigating
    
    // Redirect to another HTML page
    window.location.href = "home.html";
}