<html>
    <head>
        <title>
            btech 
        </title>
        <link rel="stylesheet" href="agri.css" type="text/css">
    </head>
    <body>
        <div class="navbar">
            <div class="logo">
                <h1><img src="cutm.jpeg" width="80" height="80"> BSC AGRICULTURE DEPARTMENT
               </h1>

            </div>
            <div class="menu">
                <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="#">Groups</a></li>
                <li><a href="#">Labs</a></li>
                <li><a href="#">Services</a></li>
            
            

                </ul>

            </div>
            

        </div>
        <div class="body">
            <div class="heading">
             <h1>BSC AGRICULTURE</h1>
             <br>
             <p> the federal department that administers programs that provide services to farmers (including research and soil conservation and efforts to stabilize the farming economy); created in 1862.    </p>
             <br>
             <br> 
             <a href="#">Learn More</a>  
            </div>
            <div class="Sub Branch">
                <div class="AGRICULTURE">
                    
                    <img src="AGRICULTURE.png" style="width: 200px; height: 150px; border-radius: 12px;">
                    <br>
                    <br>
                    <a href="agrigallery.html">AGRICULTURE</a>

                </div>
                
               
            </div>
        </div>
        <div class="footer">
            <a href="#">copy right</a>
            <a href="#">terms and conditions</a>
            <a href="#">privacy policy</a>
            <a href="#">cookies</a>
            <a href="#">complaints</a>
        </div>
    </body>
</html>