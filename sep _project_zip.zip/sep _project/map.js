import {Map, Marker, GoogleApiWrapper} from 'google-maps-react';
import {React, Component} from 'react'
export class CutmapMap extends Component {

 render() {
 return (
     <Map 
     google={this.props.google}
     style = {{width:"100", height:"100"}}
     zoom = {10}

     initialCenter = {
        {
            lat:18.26293,
            lng:83.39318
        

        }
    }
          />
          );
}
}
 export default GoogleApiWrapper({
apiKey: ('AIzaSyA6paxi6bmk0qxMMB0q-hqkVmMHU4dXpGo')
})(CutmapMap)