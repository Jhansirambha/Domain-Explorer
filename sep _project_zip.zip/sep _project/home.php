<?php
session_start();
include ("connection.php");
include ("functions.php");

$user_data= check_login($con);
?>

<html>
    <head>
        <title>
            Centurion University 
        </title>
     
        <script>
            document.getElementById('goHomeLink').addEventListener('click', function() {
                document.getElementById('home').scrollIntoView({ behavior: 'smooth' });
            });
        </script>

        <style>
            *{
    padding: 0px;
    margin: 0px;
    box-sizing: border-box;
    list-style: none;
    font-family: 'poppins', sans-serif;
}
.navbar{
    width: 100%;
    height: 80px;
    background-color: rgb(191, 170, 231);
    display: flex;
    justify-content: space-around;
    align-items: center;
    color: #000;
}
.menu ul{
    display: flex;
    align-items: center;
}
.menu ul li a{
    text-decoration: none;
    color: #000;
    padding: 5px 12px;
    letter-spacing: 2px;
    font-size: 18px;
    
}
.menu ul li a:hover{
    border-bottom: 4px solid #000;
    transition: 0.4s;

}
.signup a{
    text-decoration: none;
    color: #000;
    font-size: 18px;
    font-weight: bold;
    border-radius: 12px;
    padding: 12px 30px;
    border: 2px solid #ff0000;
}
.signup a:hover{
    background-color: red;
    transition: 0.6s;

}
.body{
    width: 100%;
    height: 90vh;
    display: flex;
    justify-content: space-around;
    align-items: center;
    background-image: linear-gradient(rgba(0,0,0,0.50),rgba(0,0,0,0.50)),url(home_bg.jpeg);
    background-position: center;
    background-size: cover;
}
.heading{
    width: 30%;
    text-align: center;
    color: #fff;

}
.heading h1{
    font-size: 40px;
}
.heading a{
    text-decoration: none;
    color: #000;
    font-size: 25px;
    font-weight: bold;
    border-radius: 45px;
    padding: 14px 50px;
    background-color: #fff;
}
.heading a:hover{
    background-color: #4896bd;
    letter-spacing: 3px;
    transition: 0.6s;
}
.Departments{
    width: 70%;
    display: flex;
    justify-content: space-around;
}
.BTECH{
    display: inline;
    text-align: center;
    border-radius: 12px;

}
.BTECH h2{
    color: rgba(205, 192, 220, 0.979);;
    font-size: 25px;
    letter-spacing: 2px;
   
}

.BTECH a{
    text-decoration: none;
    color: rgba(69, 38, 107, 0.979);
    font-weight: bold;
    font-size: 18px;
    border-radius: 12px;
    padding: 12px 30px;
    background-color: #fff;

}
.BTECH a:hover{
    background-color: #4896bd;
    letter-spacing: 3px;
    transition: 0.6s;
}
.BSC{
    display: inline;
    text-align: center;
    border-radius: 12px;

}
.BSC h2{
    color: rgba(205, 192, 220, 0.979);
    font-size: 25px;
    letter-spacing: 2px;
   
}
.BSC a{
    text-decoration: none;
    color:rgba(69, 38, 107, 0.979) ;
    font-weight: bold;
    font-size: 18px;
    border-radius: 12px;
    padding: 12px 30px;
    background-color: #fff;

}
.BSC a:hover{
    background-color: #4896bd;
    letter-spacing: 3px;
    transition: 0.6s;
}
.BBA{
    display: inline;
    text-align: center;
    border-radius: 12px;

}
.BBA h2{
    color: rgba(205, 192, 220, 0.979);;
    font-size: 25px;
    letter-spacing: 2px;
   
}
.BBA a{
    text-decoration: none;
    color: rgba(69, 38, 107, 0.979);
    font-weight: bold;
    font-size: 18px;
    border-radius: 12px;
    padding: 12px 30px;
    background-color: #fff;

}
.BBA a:hover{
    background-color: #4896bd;
    letter-spacing: 3px;
    transition: 0.6s;
}
.Agriculture{
    display: inline;
    text-align: center;
    border-radius: 12px;

}
.Agriculture h2{
    color: rgba(205, 192, 220, 0.979);;
    font-size: 25px;
    letter-spacing: 2px;
   
}

.Agriculture a{
    text-decoration: none;
    color: rgba(69, 38, 107, 0.979);
    font-weight: bold;
    font-size: 18px;
    border-radius: 12px;
    padding: 12px 30px;
    background-color: #fff;

}
.Agriculture a:hover{
    background-color: #4896bd;
    letter-spacing: 3px;
    transition: 0.6s;
}
.footer{
    width: 100%;
    height: 50px;
    display: flex;
    justify-content: space-around;
    align-items: center;

}
.footer a{
    text-decoration: none;
    color: green;
    font-size: 18px;
    font-weight: bold;
}
.footer a:hover{
    letter-spacing: 3px;
    transition: 0.6s;

}
        </style>
        
    </head>
    <body>
        <div class="navbar">
            <div class="logo">
                <h1>Centurion University </h1>

            </div>
            <div class="menu">
                <ul>
                <li><a href="login.php">Home</a></li>
                <li><a href="Departments.html">Departments</a></li>
                <li><a href="GALLERY.html">Gallery</a></li>
                <li><a href="#">Services</a></li>
                <li><a href="#">Skills</a></li><br>
                <a href="login.php" id="goHomeLink">Go Home</a>
            

                </ul>

            </div>
            <div class="Register">
                
                <a href="signup.php">sign up</a>

            </div>

        </div>
        <div class="body">
            <div class="heading">
             <h1>College Tourism</h1>
             <br>
             <p>College campus visits are important for prospective college students for a number of reasons.  </p>
             <br>
             <br> 
             <a href="#">Learn More</a>  
            </div>
            <div class="Departments">
                <div class="BTECH">
                    <h2><marquee w scrollamount="4" >Btech</marquee></h2>
                    <img src="BTECH.png" style="width: 200px; height: 150px; border-radius: 12px;">
                    <br>
                    <br>
                    <a href="btech.php">BTECH</a>

                </div>
                <div class="BSC">
                    <h2><marquee w scrollamount="4" >BSC</marquee></h2>
                    <img src="BSC.png" style="width: 200px; height: 150px; border-radius: 12px;">
                    <br>
                    <br>
                    <a href="bsc.php">BSC</a>

                </div>
                <div class="BBA">
                    <h2><marquee  scrollamount="4" >BBA</marquee></h2>
                    <img src="BBA.png" style="width: 200px; height: 150px; border-radius: 12px;">
                    <br>
                    <br>
                    <a href="bba.php">BBA</a>

                </div>
                <div class="Agriculture">
                    <h2><marquee w scrollamount="4" >Agriculture</marquee></h2>
                    <img src="AGRICULTURE.png" style="width: 200px; height: 150px; border-radius: 12px;">
                    <br>
                    <br>
                    <a href="agri.php">AGRICULTURE</a>

                </div>
            </div>
        </div>
        <div class="footer">
            <a href="#">copy right</a>
            <a href="#">terms and conditions</a>
            <a href="#">privacy policy</a>
            <a href="#">cookies</a>
            <a href="#">complaints</a>
        </div>
    </body>
</html>