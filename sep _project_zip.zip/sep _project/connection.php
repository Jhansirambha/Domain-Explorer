<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "j05@7";
$dbname = "userdata";

if(!$con=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname)){
    die("failed to connect");
}