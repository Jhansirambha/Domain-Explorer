<?php
session_start();
include("connection.php");
include("functions.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_name = $_POST['user_name'] ?? null;
    $password = $_POST['password'] ?? null;

    if ($user_name !== null && $password !== null && !is_numeric($user_name)) {
        //save to database
        $user_id = random_num(50);
        $query = "INSERT INTO userinfo (user_id,user_name,password) VALUES ('$user_id','$user_name','$password')";

        mysqli_query($con, $query); // corrected mysqli_query() to include $connection
        //redirect to login page
        header("Location: login.php");
        die;
    } else {
        echo "Please enter some valid information!";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Page</title>
    <style>
         body, html {
            height: 100%;
        }
     body {
    background-image: url('signup_bg.jpg'); /* Replace 'background_image.jpg' with your image path */
    background-size: cover;
    background-position: center;
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
}

#box {
    background-color: rgba(255, 255, 255, 0.4); /* Adjust the transparency by changing the last value (0.8) */
    margin: auto;
    width: 400px;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px 0 rgba(0, 0, 0, 0.1); /* Add a subtle shadow */
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}

#text, #button {
    height: 40px;
    border-radius: 5px;
    padding: 10px;
    border: solid thin #aaa;
    width: 95%;
    margin-bottom: 10px;
    font-size: larger;
    font-family: 'Times New Roman', Times, serif;
}

#button {
    color: white;
    background-color: pink;
    border: none;
    cursor: pointer;
}

#button:hover {
    background-color: #ff69b4; /* Change color on hover */
}

#box form div {
    font-size: 20px;
    margin: 10px;
    color: darkblue;
    text-align: center;
}

#box form a {
    color: darkblue;
    text-decoration: none;
    font-weight: bold;
}

#box form a:hover {
    color: #ff69b4; /* Change color on hover */
}




    </style>
</head>
<body>
<div id="box">
    <form method="post">
        <div style="font-size: 30px;margin: 10px;color: darkblue;">Signup</div>
        <input id="text" type="text" name="user_name" placeholder="Enter USERNAME"><br><br>
        <input id="text" type="password" name="password" placeholder="Enter  PASSWORD"><br><br>
        <input id="button" type="submit" value="Signup"><br><br>
        <p>Already have an account ? </p>
        <a href="login.php"> Click here to Login</a><br><br>

    </form>
</div>

</div>
</body>
</html>
