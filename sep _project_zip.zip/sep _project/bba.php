<html>
    <head>
        <title>
            bba 
        </title>
        <link rel="stylesheet" href="bba.css" type="text/css">
    </head>
    <body>
        <div class="navbar">
            <div class="logo">
                <h1>BBA DEPARTMENT</h1>

            </div>
            <div class="menu">
                <ul>
                <li><a href="home.php">Home</a></li>
                
                <li><a href="#">Labs</a></li>
                <li><a href="#">Services</a></li>
            
            

                </ul>

            </div>
           

        </div>
        <div class="body">
            <div class="heading">
             <h1>BBA</h1>
             <br>
             <p>A bachelor's degree that helps you establish a fundamental understanding of business and how various aspects of it apply to the real world. </p>
             <br>
             <br> 
             <a href="#">Learn More</a>  
            </div>
            <div class="Sub Branch">
                <div class="Marketing">
                    
                    <img src="MARKETING.png" style="width: 200px; height: 150px; border-radius: 12px;">
                    <br>
                    <br>
                    <a href="bbamgallery.html">Marketing</a>

                </div>
                <div class="Insurance">
                    
                    <img src="INSURANCE.png" style="width: 200px; height: 150px; border-radius: 12px;">
                    <br>
                    <br>
                    <a href="bbaigallery.html">Insurance</a>

                </div>
                
            </div>
        </div>
        <div class="footer">
            <a href="#">copy right</a>
            <a href="#">terms and conditions</a>
            <a href="#">privacy policy</a>
            <a href="#">cookies</a>
            <a href="#">complaints</a>
        </div>
    </body>
</html>