<?php
session_start();
include("connection.php");
include("functions.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_name = $_POST['user_name'] ?? null;
    $password = $_POST['password'] ?? null;

    if ($user_name !== null && $password !== null && !is_numeric($user_name)) {
        //read from the database
        $query = "SELECT * FROM userinfo WHERE user_name ='$user_name' limit 1";

        $result = mysqli_query($con, $query); 

        if($result)
        {
            if($result && mysqli_num_rows($result) > 0)
            {
                $user_data=mysqli_fetch_assoc($result);
                if($user_data['password'] === $password)
                {
                    $_SESSION['user_id'] = $user_data['user_id'];
                    header("Location: home.php");
                    die;
                }
            }
        }
        echo '<div id="errorbox">Wrong Username or Password </div>';
        
    } else {
        echo "Please enter some valid information!";
    }
}


?>
<!DOCTYPE html>
<head>
    <title>Login Page</title>
</head>
<body>
    <style type="text/css"> 
    body, html {
    height: 100%;
}
       body {
    background-image: url('register_bg.jpg'); /* Replace 'background_image.jpg' with your image path */
    background-size: cover;
    background-position: center;
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
}

#box {
    background-color: rgba(255, 255, 255, 0.4); /* Adjust the transparency by changing the last value (0.8) */
  
    width: 400px;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px 0 rgba(0, 0, 0, 0.1); /* Add a subtle shadow */
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}

#text, #button {
    height: 40px;
    border-radius: 5px;
    padding: 10px;
    border: solid thin #aaa;
    width: 95%;
    margin-bottom: 10px;
    font-size: larger;
    font-family: 'Times New Roman', Times, serif;
}

#button {
    color: white;
    background-color: pink;
    border: none;
    cursor: pointer;
}

#button:hover {
    background-color: #ff69b4; /* Change color on hover */
}

#box form div {
    font-size: 20px;
    margin: 10px;
    color: darkblue;
    text-align: center;
}

#box form a {
    color: darkblue;
    text-decoration: none;
    font-weight: bold;
}

#box form a:hover {
    color: #ff69b4; /* Change color on hover */
}


#errorBox {
    background-color: plum; /* Light red background color */
    color: purple; /* Dark red text color */
    padding: 15px;
    border-radius: 500px;
    margin-top: 10px; /* Add some space from the form elements */
    text-align: center;
    font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif ;
    font-size: larger;
    
}
          
</style>
<div id="box">
    <form method="post">
        <div style="font-size: 30px;margin: 10px;color: darkblue;">Login</div>
        <input id="text" type="text" name="user_name" placeholder="Enter your existed Username"><br><br>
        <input id="text" type="password" name="password" placeholder="Enter your password"><br><br>
        <input id="button" type="submit" value="Login"><br><br>
        <p> Not have an Account yet? </p>
        <a href="signup.php">Click to Signup</a><br><br>

    </form>
    
</div>
</body>
</html>