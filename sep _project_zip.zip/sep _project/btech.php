<html>
    <head>
        <meta charset="=UTF-8">
        <title>
            btech 
        </title>
        <meta name="viewport" content="width=device-width,initial-scale =1.0">
        <style>
            *{
    padding: 0px;
    margin: 0px;
    box-sizing: border-box;
    list-style: none;
    font-family: 'poppins', sans-serif;
}
.navbar{
    width: 100%;
    height: 80px;
    background-color: rgb(191, 170, 231);
    display: flex;
    justify-content: space-around;
    align-items: center;
    color: #000;
}
.menu ul{
    display: flex;
    align-items: center;
}
.menu ul li a{
    text-decoration: none;
    color: #000;
    padding: 5px 12px;
    letter-spacing: 2px;
    font-size: 18px;
    
}
.menu ul li a:hover{
    border-bottom: 4px solid #000;
    transition: 0.4s;

}
.profile a{
    text-decoration: none;
    color: #fcfcfc;
    font-size: 18px;
    font-weight: bold;
    border-radius: 12px;
    padding: 12px 30px;
    border: 2px solid rgba(69, 38, 107, 0.979);
}
.profile a:hover{
    background-color: rgba(69, 38, 107, 0.979);
    transition: 0.6s;

}
.body{
    width: 100%;
    height: 90vh;
    display: flex;
    justify-content: space-around;
    align-items: center;
    background-image: linear-gradient(rgba(0,0,0,0.50),rgba(0,0,0,0.50)),url(home_bg.jpeg);
    background-position: center;
    background-size: cover;
}
.heading{
    width: 30%;
    text-align: center;
    color: #fff;

}
.heading h1{
    font-size: 40px;
}
.heading a{
    text-decoration: none;
    color: #000;
    font-size: 25px;
    font-weight: bold;
    border-radius: 45px;
    padding: 14px 50px;
    background-color: #fff;
}
.heading a:hover{
    background-color: #4896bd;
    letter-spacing: 3px;
    transition: 0.6s;
}
.sub{
    width: 70%;
    display: flex;
    justify-content: space-around;
}
.Web {
    display: inline;
    text-align: center;
    border-radius: 12px;

}
.Web h2{
    color: red;
    font-size: 35px;
    letter-spacing: 3px;
    border-radius: 1px;
    padding: 30px 30px;
    background-color: #000;
}
.Web a{
    text-decoration: none;
    color: rgba(69, 38, 107, 0.979);
    font-weight: bold;
    font-size: 18px;
    border-radius: 12px;
    padding: 12px 30px;
    background-color: #fff;

}
.Web a:hover{
    background-color: #4896bd;
    letter-spacing: 1px;
    transition: 0.6s;
}
.Data{
    display: inline;
    text-align: center;
    border-radius: 12px;

}
.Data h2{
    color: red;
    font-size: 35px;
    letter-spacing: 3px;
    border-radius: 1px;
    padding: 30px 30px;
    background-color: #000;
}
.Data a{
    text-decoration: none;
    color: rgba(69, 38, 107, 0.979);
    font-weight: bold;
    font-size: 18px;
    border-radius: 12px;
    padding: 12px 30px;
    background-color: #fff;

}
.Data  a:hover{
    background-color: #4896bd;
    letter-spacing: 1px;
    transition: 0.6s;
}
.AI{
    display: inline;
    text-align: center;
    border-radius: 12px;

}
.AI h2{
    color: red;
    font-size: 35px;
    letter-spacing: 3px;
    border-radius: 1px;
    padding: 30px 30px;
    background-color: #000;
}
.AI a{
    text-decoration: none;
    color: rgba(69, 38, 107, 0.979);
    font-weight: bold;
    font-size: 18px;
    border-radius: 12px;
    padding: 12px 30px;
    background-color: #fff;

}
.AI a:hover{
    background-color: #4896bd;
    letter-spacing: 1px;
    transition: 0.6s;
}
.Cyber{
    display: inline;
    text-align: center;
    border-radius: 12px;

}
.Cyber h1{
    color: red;
    font-size: 30px;
    letter-spacing: 3px;
    border-radius: 1px;
    padding: 30px 30px;
    
}
.Cyber a{
    text-decoration: none;
    color: rgba(69, 38, 107, 0.979);
    font-weight: bold;
    font-size: 18px;
    border-radius: 12px;
    padding: 12px 30px;
    background-color: #fff;

}
.Cyber a:hover{
    background-color: #4896bd;
    letter-spacing: 1px;
    transition: 0.6s;
}
.ECE{
    display: inline;
    text-align: center;
    border-radius: 12px;

}
.ECE h1{
    color: red;
    font-size: 30px;
    letter-spacing: 3px;
    border-radius: 1px;
    padding: 30px 30px;
    
}
.ECE a{
    text-decoration: none;
    color: rgba(69, 38, 107, 0.979);
    font-weight: bold;
    font-size: 18px;
    border-radius: 12px;
    padding: 12px 30px;
    background-color: #fff;

}
.ECE a:hover{
    background-color: #4896bd;
    letter-spacing: 1px;
    transition: 0.6s;
}
.footer{
    width: 100%;
    height: 50px;
    display: flex;
    justify-content: space-around;
    align-items: center;

}
.footer a{
    text-decoration: none;
    color: green;
    font-size: 18px;
    font-weight: bold;
}
.footer a:hover{
    letter-spacing: 3px;
    transition: 0.6s;

}
        </style>
    </head>
    <body>
        <div class="navbar">
            <div class="logo">
                <h1>B.TECH DEPARTMENT</h1>

            </div>
            <div class="menu">
                <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="#">Labs</a></li>
                <li><a href="index.html">Map</a></li>
            
            

                </ul>

            </div>
            

        </div>
        <div class="body">
            <div class="heading">
             <h1>B.TECH</h1>
             <br>
             <p>Engineers, holding the title of builders of our modern world; they're the dreamers, problem-solvers,   </p>
             <br>
             <br> 
             <a href="btechlearnmore.html">Learn More</a>  
            </div>
            <div class="Sub Branch">
                <div class="Web Developement">
                    
                    <img src="WEB_DEV.png" style="width: 200px; height: 150px; border-radius: 12px;">
                    <br>
                    <br>
                    <a href="webgallery.html">Web Developement</a>

                </div>
                <div class="Data science">
                    
                    <img src="DS.png" style="width: 200px; height: 150px; border-radius: 12px;">
                    <br>
                    <br>
                    <a href="dsgallery.html">Data science</a>

                </div>
                <div class="AI">
                    
                    <img src="AI.png" style="width: 200px; height: 150px; border-radius: 12px;">
                    <br>
                    <br>
                    <a href="aigallery.html">AI</a>

                </div>
                
                <div class="cyber security">
                    
                    <img src="CNS.png" style="width: 200px; height: 150px; border-radius: 12px;">
                    <br>
                    <br>
                    <a href="csgallery.html">cyber security</a>

                </div>
                <div class="ECE">
                    
                    <img src="ECE.png" style="width: 200px; height: 150px; border-radius: 12px;">
                    <br>
                    <br>
                    <a href="ecegallery.html">ECE</a>

                </div>
            </div>
        </div>
        <div class="footer">
            <a href="#">copy right</a>
            <a href="#">terms and conditions</a>
            <a href="#">privacy policy</a>
            <a href="#">cookies</a>
            <a href="#">complaints</a>
        </div>
    </body>
</html>